package co.edu.uniremington.SpringTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
